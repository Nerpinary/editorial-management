PRAGMA foreign_keys=OFF;
BEGIN TRANSACTION;
CREATE TABLE editorial_departments (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL UNIQUE,
      monthly_articles INTEGER DEFAULT 0,
      description TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );
INSERT INTO editorial_departments VALUES(1,'Бизнес',6,NULL,'2025-10-03 18:29:13');
INSERT INTO editorial_departments VALUES(2,'Вещи',86,NULL,'2025-10-03 18:29:13');
INSERT INTO editorial_departments VALUES(3,'Вложения',13,NULL,'2025-10-03 18:29:13');
INSERT INTO editorial_departments VALUES(4,'Город',5,NULL,'2025-10-03 18:29:13');
INSERT INTO editorial_departments VALUES(5,'Дети',5,NULL,'2025-10-03 18:29:13');
INSERT INTO editorial_departments VALUES(6,'Едакция',22,NULL,'2025-10-03 18:29:13');
INSERT INTO editorial_departments VALUES(7,'Животные',6,NULL,'2025-10-03 18:29:13');
INSERT INTO editorial_departments VALUES(8,'Интернет',18,NULL,'2025-10-03 18:29:13');
INSERT INTO editorial_departments VALUES(9,'Интервью',5,NULL,'2025-10-03 18:29:13');
INSERT INTO editorial_departments VALUES(10,'Кто помогает',10,NULL,'2025-10-03 18:29:13');
INSERT INTO editorial_departments VALUES(11,'Медицина',18,NULL,'2025-10-03 18:29:13');
INSERT INTO editorial_departments VALUES(12,'Мозг',15,NULL,'2025-10-03 18:29:13');
INSERT INTO editorial_departments VALUES(13,'Недвижимость',18,NULL,'2025-10-03 18:29:13');
INSERT INTO editorial_departments VALUES(14,'Образование',1,NULL,'2025-10-03 18:29:13');
INSERT INTO editorial_departments VALUES(15,'Поп-культура',42,NULL,'2025-10-03 18:29:13');
INSERT INTO editorial_departments VALUES(16,'Право',1,NULL,'2025-10-03 18:29:13');
INSERT INTO editorial_departments VALUES(17,'Списки',52,NULL,'2025-10-03 18:29:13');
INSERT INTO editorial_departments VALUES(18,'Гайды',20,NULL,'2025-10-03 18:29:13');
INSERT INTO editorial_departments VALUES(19,'Сравнятор',17,NULL,'2025-10-03 18:29:13');
INSERT INTO editorial_departments VALUES(20,'Статистика',7,NULL,'2025-10-03 18:29:13');
INSERT INTO editorial_departments VALUES(21,'Тесты',10,NULL,'2025-10-03 18:29:13');
INSERT INTO editorial_departments VALUES(22,'Техника',5,NULL,'2025-10-03 18:29:13');
INSERT INTO editorial_departments VALUES(23,'Чемодан',10,NULL,'2025-10-03 18:29:13');
INSERT INTO editorial_departments VALUES(24,'ЧД',42,NULL,'2025-10-03 18:29:13');
INSERT INTO editorial_departments VALUES(25,'ЧД-микро',32,NULL,'2025-10-03 18:29:13');
INSERT INTO editorial_departments VALUES(26,'Шорты',89,NULL,'2025-10-03 18:29:13');
INSERT INTO editorial_departments VALUES(27,'Новости',170,NULL,'2025-10-03 18:29:13');
INSERT INTO editorial_departments VALUES(28,'UGC',290,NULL,'2025-10-03 18:29:13');
INSERT INTO editorial_departments VALUES(29,'Тюнинг',460,NULL,'2025-10-03 18:29:13');
INSERT INTO editorial_departments VALUES(30,'Подкасты и Видео',15,NULL,'2025-10-03 18:29:13');
INSERT INTO editorial_departments VALUES(31,'Дневники трат',10,NULL,'2025-10-03 18:29:13');
INSERT INTO editorial_departments VALUES(32,'Вакансии',9,NULL,'2025-10-03 18:29:13');
INSERT INTO editorial_departments VALUES(33,'Фичеры',10,NULL,'2025-10-03 18:29:13');
INSERT INTO editorial_departments VALUES(34,'Спорт',18,NULL,'2025-10-03 18:29:13');
INSERT INTO editorial_departments VALUES(103,'Спецы',2,'','2025-10-03 18:38:25');
INSERT INTO editorial_departments VALUES(104,'Безопасность',6,'','2025-10-03 18:40:30');
INSERT INTO editorial_departments VALUES(105,'Авто',1,'','2025-10-03 18:44:43');
INSERT INTO editorial_departments VALUES(106,'Баннеры',0,'','2025-10-03 18:57:12');
INSERT INTO editorial_departments VALUES(107,'Учебник',0,'','2025-10-03 18:57:20');
CREATE TABLE employees (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      email TEXT UNIQUE,
      category TEXT NOT NULL CHECK (category IN ('СМВ', 'МВ', 'ММВ')),
      capacity REAL DEFAULT 1.0,
      preferred_departments TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );
INSERT INTO employees VALUES(1,'Цицеронова','tsitseronova@example.com','СМВ',0.8000000000000000444,'["Новости"]','2025-10-03 18:29:33');
INSERT INTO employees VALUES(2,'Томас','tomas@example.com','СМВ',0.8000000000000000444,'["Вещи"]','2025-10-03 18:29:33');
INSERT INTO employees VALUES(3,'Попова','popova@example.com','СМВ',0.8000000000000000444,'["Учебник"]','2025-10-03 18:29:33');
INSERT INTO employees VALUES(4,'Афонина','afonina@example.com','СМВ',0.8000000000000000444,'["Бизнес","Город","Чемодан","Образование"]','2025-10-03 18:29:33');
INSERT INTO employees VALUES(5,'Гелета','geleta@example.com','СМВ',0.8000000000000000444,'["Спорт","Мозг","Дети","Новости"]','2025-10-03 18:29:33');
INSERT INTO employees VALUES(6,'Недашковская','nedashkovskaya@example.com','СМВ',0.8000000000000000444,'["Вложения","Едакция","Новости"]','2025-10-03 18:29:33');
INSERT INTO employees VALUES(7,'Панфилова','panfilova@example.com','СМВ',0.8000000000000000444,'["Дневники трат","Животные","Недвижимость","Право","Статистика"]','2025-10-03 18:29:33');
INSERT INTO employees VALUES(8,'Шалыгин','shalygin@example.com','СМВ',0.8000000000000000444,'["UGC"]','2025-10-03 18:29:33');
INSERT INTO employees VALUES(9,'Шарахматова','sharahmatova@example.com','СМВ',0.8000000000000000444,'["Списки","Подкасты и Видео","Баннеры"]','2025-10-03 18:29:33');
INSERT INTO employees VALUES(10,'Гуртовая','gurtovaya@example.com','СМВ',0.8000000000000000444,'["Шорты","UGC"]','2025-10-03 18:29:33');
INSERT INTO employees VALUES(11,'Томберг','tomberg@example.com','СМВ',0.8000000000000000444,'["Гайды","Техника","Спорт","ЧД","ЧД-микро"]','2025-10-03 18:29:33');
INSERT INTO employees VALUES(12,'Гоцманова','gotsmanova@example.com','СМВ',0.8000000000000000444,'["Спецы","Интервью","Медицина","Поп-культура","Тесты"]','2025-10-03 18:29:33');
INSERT INTO employees VALUES(13,'Павлов','pavlov@example.com','СМВ',0.8000000000000000444,'["Авто","Безопасность","Едакция","Интернет","Кто помогает","Поп-культура","Фичеры","Новости"]','2025-10-03 18:29:33');
INSERT INTO employees VALUES(14,'Тимофеева','timofeeva@example.com','СМВ',0.8000000000000000444,'["Дети","Дневники трат","Интернет","Недвижимость","Мозг","Поп-культура","Сравнятор","Тесты"]','2025-10-03 18:29:33');
INSERT INTO employees VALUES(15,'Переседова','peresedova@example.com','СМВ',0.8000000000000000444,'["Бизнес","Дневники трат","Животные","Подкасты и Видео","Медицина","Поп-культура","Спорт","Шорты","Новости"]','2025-10-03 18:29:33');
INSERT INTO employees VALUES(16,'Легостаева','legostaeva@example.com','СМВ',0.8000000000000000444,'["Новости","Вакансии","Интернет","Медицина","Сравнятор","ЧД","ЧД-микро"]','2025-10-03 18:29:33');
INSERT INTO employees VALUES(17,'Боткина','botkina@example.com','МВ',1.0,'["UGC","Животные","Сравнятор","Медицина","Кто помогает","Вложения"]','2025-10-03 18:29:33');
INSERT INTO employees VALUES(18,'Черкасова','cherkasova@example.com','МВ',1.0,'["Новости","Спецы","Списки","Шорты","UGC"]','2025-10-03 18:29:33');
INSERT INTO employees VALUES(19,'Дейкина','deykina@example.com','МВ',1.0,'["Гайды","Дневники трат","Чемодан","Интервью","Город","Бизнес","Право"]','2025-10-03 18:29:33');
INSERT INTO employees VALUES(20,'Зовутин','zovutin@example.com','МВ',1.0,'["Безопасность","Гайды","Вложения","Кто помогает","Недвижимость","Образование","ЧД","ЧД-микро"]','2025-10-03 18:29:33');
INSERT INTO employees VALUES(21,'Иванова Наташа','ivanova_n@example.com','МВ',1.0,'["Дети","Списки","Фичеры","ЧД","UGC","ЧД-микро"]','2025-10-03 18:29:33');
INSERT INTO employees VALUES(22,'Рубин','rubin@example.com','МВ',1.0,'["Новости","Техника","Чемодан","Шорты","ЧД","Спецы","ЧД-микро"]','2025-10-03 18:29:33');
INSERT INTO employees VALUES(23,'Хохлов','khozlov@example.com','МВ',1.0,'["Учебник"]','2025-10-03 18:29:33');
INSERT INTO employees VALUES(24,'Корепанов','korepanov@example.com','МВ',1.0,'["Учебник"]','2025-10-03 18:29:33');
INSERT INTO employees VALUES(25,'Моисеев','moiseev@example.com','МВ',1.0,'["Учебник"]','2025-10-03 18:29:33');
INSERT INTO employees VALUES(26,'Козлов','kozlov@example.com','ММВ',1.300000000000000044,'["Образование","Тесты","Фичеры","Баннеры"]','2025-10-03 18:29:33');
INSERT INTO employees VALUES(27,'Смолянко','smolyanko@example.com','ММВ',1.300000000000000044,'["Город","Интервью","Мозг","Поп-культура","Списки","Шорты","Фичеры","UGC"]','2025-10-03 18:29:33');
INSERT INTO employees VALUES(28,'Черный','chernyy@example.com','ММВ',1.300000000000000044,'["Статистика","Вещи"]','2025-10-03 18:29:33');
INSERT INTO employees VALUES(29,'Иванова Алина','ivanova_a@example.com','ММВ',1.300000000000000044,'["Вещи","Едакция"]','2025-10-03 18:29:33');
INSERT INTO employees VALUES(30,'Никитин','nikitin@example.com','ММВ',1.300000000000000044,'["Гайды","Авто","Статистика","Списки"]','2025-10-03 18:29:33');
INSERT INTO employees VALUES(31,'Домашенков','domashenkov@example.com','ММВ',1.300000000000000044,'["UGC","Списки","Безопасность","Техника","Шорты"]','2025-10-03 18:29:33');
INSERT INTO employees VALUES(32,'Брежнева','brezhneva@example.com','ММВ',1.300000000000000044,'["Вещи","Дневники трат"]','2025-10-03 18:29:33');
CREATE TABLE employee_assignments (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      employee_id INTEGER,
      department_id INTEGER,
      workload_percentage REAL DEFAULT 0.0,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (employee_id) REFERENCES employees (id) ON DELETE CASCADE,
      FOREIGN KEY (department_id) REFERENCES editorial_departments (id) ON DELETE CASCADE,
      UNIQUE(employee_id, department_id)
    );
INSERT INTO sqlite_sequence VALUES('editorial_departments',107);
INSERT INTO sqlite_sequence VALUES('employees',64);
INSERT INTO sqlite_sequence VALUES('employee_assignments',7);
COMMIT;
